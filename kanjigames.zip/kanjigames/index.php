<!-- <?php
        include('crud/connection.php');
        ?> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Kanji Games</title>
</head>

<body id="check">
    <div class="overlay">
        <div class="modal">
            <div class="head">
                <p>Select Level</p>
                <button onclick="off()">x</button>
            </div>
            <div class="body">
                <div style="display: flex;">
                    <p>Hiragana</p>
                    <button onclick="beginerhiragana()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Katakana</p>
                    <button onclick="beginerkatakana()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Kanji N5</p>
                    <button onclick="beginerkanjin5()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Kanji N4</p>
                    <button onclick="beginerkanjin4()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Kanji N3</p>
                    <button onclick="beginerkanjin3()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Kanji N2</p>
                    <button onclick="beginerkanjin2()">0</button>
                </div>
                <div style="display: flex;">
                    <p>Kanji N1</p>
                    <button onclick="beginerkanjin1()">0</button>
                </div>
            </div>
            <div class="bottom">
                <div class="top">
                    <p>Swipe Up For Next Question</p>
                </div>
                <!-- <p>If You Use Computer Device :</p>
                <div class="middle">
                    <p>Press 1 = Answer 1 | Press 2 = Answer 2 | Press 3 = Answer 3</p>
                    <p>Press 4 = Answer 4 | Press 5 = Answer 5 | Press 6 = Answer 6</p>
                    <p>Press 7 = Answer 7 | Press 8 = Answer 8 | Press 9 = Answer 9</p>
                </div>
                <div class="last">
                    <p>Press Tab/Space/Enter = Next Question</p>
                </div> -->
            </div>
        </div>
    </div>
    <div class="content">
        <div>
            <nav>
                <div class="right">
                    <p id="level">Kanji N5</p>
                    <button onclick="on()">Select Level</button>
                </div>
                <div class="left">
                    <p id="benar">Benar : 0</p>
                    <p id="salah">Salah : 0</p>
                    <p id="sisa">Tersisa : 0</p>
                    <p id="persen">0%</p>
                </div>
            </nav>
        </div>
        <div>
            <a class="insert" style="display: none;" href="crud/entercode.php"></a>
        </div>
        <div class="box centered">
            <div class="question">
                <p></p>
                <div id="answer">
                    <div class="up">
                        <div class="kanji">
                            <p id="kanji"></p>
                        </div>
                        <div class="means">
                            <div class="top">
                                <p class="means">Onyomi</p>
                                <p id="onyomi"></p>
                            </div>
                            <div class="down">
                                <p class="means">Kunyomi</p>
                                <p id="kunyomi"></p>
                            </div>
                        </div>
                    </div>
                    <div class="down">
                        <p id="sense"></p>
                        <!-- <p id="sense">Swipe Up</p> -->
                    </div>
                </div>
            </div>
            <div class="answer">
                <div class="position">
                    <div class="answer-btn"><button class="checkAnswer 1" id="1"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 2" id="2"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 3" id="3"></button></div>
                </div>
                <div class="position">
                    <div class="answer-btn"><button class="checkAnswer 4" id="4"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 5" id="5"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 6" id="6"></button></div>
                </div>
                <div class="position">
                    <div class="answer-btn"><button class="checkAnswer 7" id="7"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 8" id="8"></button></div>
                    <div class="answer-btn"><button class="checkAnswer 9" id="9"></button></div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php include('data.php') ?>

</html>