<?php
include('connection.php');

$data = json_decode(file_get_contents("php://input"), true);
print $data;

if ($data) {
    $value = $data['value'];
    $result = $connection->query("SELECT * FROM `$value`")->fetchAll();
    echo json_encode($result);
} else {
    $defaultValue = "";
    $result = $connection->query("SELECT * FROM `$defaultValue`")->fetchAll();
    echo json_encode($result);
}
