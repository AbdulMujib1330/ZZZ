<?php
$connection = new PDO("mysql:host=localhost;dbname=web_data_kanji", "root", "");

