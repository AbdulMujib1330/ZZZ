<?php
include('crud/connection.php');
?>
<script>
    var check = document.getElementById("check");
    var number_1 = document.getElementById("1");
    var number_2 = document.getElementById("2");
    var number_3 = document.getElementById("3");
    var number_4 = document.getElementById("4");
    var number_5 = document.getElementById("5");
    var number_6 = document.getElementById("6");
    var number_7 = document.getElementById("7");
    var number_8 = document.getElementById("8");
    var number_9 = document.getElementById("9");


    var outsideAsk = document.getElementsByClassName("question");
    var ask = document.querySelector("div.question p");
    var answer = document.getElementById("answer");
    answer.style.display = "none";

    var modal = document.getElementsByClassName("overlay");
    var level = document.getElementById("level");

    function on() {
        for (var i = 0; i < modal.length; i++) {
            modal[i].style.display = "";
        }
    }

    function beginerhiragana() {
        alert("Masih Dalam Proses Pembuatan");
    }

    function beginerkatakana() {
        alert("Masih Dalam Proses Pembuatan");
    }

    function beginerkanjin5() {
        var kanji = "kanjin5";
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "crud/data.php", true);
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.send(JSON.stringify({
            "value": kanji
        }));
        level.innerHTML = "Kanji N5";
        off();
    }

    function beginerkanjin4() {
        var kanji = "kanjin4";
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "crud/data.php", true);
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.onload = function() {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                console.log("Response from PHP:", response);
                console.log(xhr.responseText);
            }
        };

        xhr.send(JSON.stringify({
            "value": kanji
        }));
        level.innerHTML = "Kanji N4";
        off();
    }



    function beginerkanjin3() {
        alert("Masih Dalam Proses Pembuatan");
    }

    function beginerkanjin2() {
        alert("Masih Dalam Proses Pembuatan");
    }

    function beginerkanjin1() {
        alert("Masih Dalam Proses Pembuatan");
    }

    function play() {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);
                console.log(data);
                var soal = data.length;

                function generateRandomIndices(length) {
                    var indices = [];
                    while (indices.length < soal) {
                        var randomIndex = Math.floor(Math.random() * length);
                        if (!indices.includes(randomIndex)) {
                            indices.push(randomIndex);
                        }
                    }
                    return indices;
                }


                function shuffleArray(array) {
                    for (var i = array.length - 1; i > 0; i--) {
                        var j = Math.floor(Math.random() * (i + 1));
                        [array[i], array[j]] = [array[j], array[i]];
                    }
                }

                var randomIndices = generateRandomIndices(data.length);
                var questions = randomIndices.map(function(randomIndex, index) {
                    var wrongIndices = randomIndices.filter(function(i) {
                        return i !== randomIndex;
                    });

                    var options = [
                        data[randomIndex]["sense"],
                        data[wrongIndices[(index + 1) % 9]]["sense"],
                        data[wrongIndices[(index + 2) % 9]]["sense"],
                        data[wrongIndices[(index + 3) % 9]]["sense"],
                        data[wrongIndices[(index + 4) % 9]]["sense"],
                        data[wrongIndices[(index + 5) % 9]]["sense"],
                        data[wrongIndices[(index + 6) % 9]]["sense"],
                        data[wrongIndices[(index + 7) % 9]]["sense"],
                        data[wrongIndices[(index + 8) % 9]]["sense"]
                    ];

                    shuffleArray(options);

                    return {
                        question: data[randomIndex]["kanji"],
                        kanji: data[randomIndex]["kanji"],
                        onyomi: data[randomIndex]["onyomi"],
                        kunyomi: data[randomIndex]["kunyomi"],
                        options: options,
                        correctAnswer: data[randomIndex]["sense"]

                    };

                });
                var currentQuestionIndex = -1;

                function displayNextQuestion() {
                    soal--;
                    document.getElementById("sisa").innerHTML = "Tersisa : " + soal;
                    currentQuestionIndex++;
                    if (currentQuestionIndex < questions.length) {
                        var value = document.querySelector("div.question p");
                        value.innerHTML = questions[currentQuestionIndex].question;

                        document.querySelector("div.question div#answer div p#kanji").innerHTML = questions[currentQuestionIndex].kanji;
                        document.querySelector("div.question div#answer div p#onyomi").innerHTML = questions[currentQuestionIndex].onyomi;
                        document.querySelector("div.question div#answer div p#kunyomi").innerHTML = questions[currentQuestionIndex].kunyomi;
                        document.querySelector("div.question div#answer div p#sense").innerHTML = questions[currentQuestionIndex].correctAnswer;

                        const options = document.getElementsByClassName("checkAnswer");
                        shuffleArray(questions[currentQuestionIndex].options);

                        for (let i = 0; i < options.length; i++) {
                            options[i].removeEventListener("click", handleOptionClick);
                            options[i].innerText = questions[currentQuestionIndex].options[i];
                        }

                        for (let i = 0; i < options.length; i++) {
                            options[i].addEventListener("click", handleOptionClick);
                        }
                        for (let i = 0; i < options.length; i++) {
                            options[i].addEventListener("click", handleOptionClick);
                        }
                    } else {
                        alert("Nice");
                        resetGame();
                        return
                    }
                }

                function handleOptionClick(event) {
                    var selectedValue = event.target.innerText;
                    checkAnswer(selectedValue);
                }

                function resetGame() {
                    currentQuestionIndex = -1;
                    location.reload();
                }

                var calculate = 0;

                var correct = 0;
                var incorrect = 0;

                function checkAnswer(selectedValue) {
                    ++calculate;
                    if (selectedValue === questions[currentQuestionIndex].correctAnswer) {
                        correct = ++correct
                        correctAnswer(selectedValue);
                    } else {
                        incorrect = ++incorrect
                        incorrectAnswer(selectedValue);
                    }
                    var persen = (correct / calculate) * 100;
                    var persenInt = parseInt(persen);
                    document.getElementById("persen").innerHTML = persenInt + "%";
                }

                var navLeft = document.querySelectorAll("nav div.left");


                function correctAnswer(selectedValue) {
                    valueCorrect = document.getElementById("benar");
                    ask.style.display = "none";
                    answer.style.display = "block";
                    for (var i = 0; i < outsideAsk.length; i++) {
                        outsideAsk[i].style.border = "5px solid lime";
                        outsideAsk[i].style.marginBottom = "7px";
                    }
                    for (var i = 0; i < navLeft.length; i++) {
                        navLeft[i].style.backgroundColor = "lime"
                    }
                    valueCorrect.innerHTML = "Benar : " + correct;
                    swipe()
                }

                function incorrectAnswer() {
                    valueIncorrect = document.getElementById("salah");
                    ask.style.display = "none";
                    answer.style.display = "block";
                    for (var i = 0; i < outsideAsk.length; i++) {
                        outsideAsk[i].style.border = "5px solid red";
                        outsideAsk[i].style.marginBottom = "7px";
                    }
                    for (var i = 0; i < navLeft.length; i++) {
                        navLeft[i].style.backgroundColor = "red"
                    }
                    valueIncorrect.innerHTML = "Salah : " + incorrect;
                    swipe()
                }
                let isSwipe = false;

                function swipe() {
                    isSwipe = true;
                    if (isSwipe) {
                        if (phoneDevice()) {
                            swipePhone();
                        } else {
                            swipePc();
                        }
                    }
                }

                function swipePhone() {
                    let startYHpStart = 0;
                    let startYHp;

                    answer.addEventListener("touchstart", function(event) {
                        startYHp = event.touches[0].clientY;
                        startYHpStart = startYHp;
                    });

                    window.addEventListener("touchend", function(event) {
                        startYHp = event.changedTouches[0].clientY;
                        let startYHpEnd = startYHp;
                        if (startYHpStart !== 0 && startYHpStart > startYHpEnd + 120) {
                            if (isSwipe) {
                                next();
                            }
                        }
                    });

                }

                function swipePc() {
                    let startYPcStart = 0;
                    let startYPc;

                    answer.addEventListener("mousedown", function(event) {
                        startYPc = event.clientY;
                        startYPcStart = startYPc;
                    });

                    window.addEventListener("mouseup", function(event) {
                        startYPc = event.clientY;
                        let startYPcEnd = startYPc;
                        if (startYPcStart !== 0 && startYPcStart > startYPcEnd + 120) {
                            if (isSwipe) {
                                next();
                            }
                        }
                    });
                }

                function next() {
                    ask.style.display = "";
                    answer.style.display = "none";
                    for (var i = 0; i < outsideAsk.length; i++) {
                        outsideAsk[i].style.border = "1px solid black";
                        outsideAsk[i].style.marginBottom = "15px";
                    }
                    displayNextQuestion()
                    isSwipe = false
                }

                function phoneDevice() {
                    return window.innerWidth <= 768;
                }
                displayNextQuestion();


                check.addEventListener("keydown", function(event) {

                    if (event.key === "1") {
                        no_1();
                    }
                    if (event.key === "2") {
                        no_2();
                    }
                    if (event.key === "3") {
                        no_3();
                    }
                    if (event.key === "4") {
                        no_4();
                    }
                    if (event.key === "5") {
                        no_5();
                    }
                    if (event.key === "6") {
                        no_6();
                    }
                    if (event.key === "7") {
                        no_7();
                    }
                    if (event.key === "8") {
                        no_8();
                    }
                    if (event.key === "9") {
                        no_9();
                    }
                    if (event.key === "Enter") {
                        next();
                    }
                    if (event.which === 32) {
                        next();
                    }
                });
            }
        };

        xhr.open("GET", "crud/data.php", true);
        xhr.send();
    }

    function off() {
        for (var i = 0; i < modal.length; i++) {
            modal[i].style.display = "none";
        }
        play()
    }
</script>